<?php   
    namespace app\admin\model;  
    use think\Model;  
    class Admin extends Model{ 
       //默认主键为自动识别，如果需要指定，可以这样设置属性：	
       //protected $pk = 'adminName'; 
    }  
?>
