<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:73:"D:\xampp\htdocs\HelloTP\public/../application/user\view\index\detail.html";i:1720667683;s:57:"D:\xampp\htdocs\HelloTP\application\user\view\layout.html";i:1720668512;}*/ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>B2C网站</title>
<style>
ul{overflow:hidden;width:100%;}
ul li{list-style:none;width:33.333%;float:left;}
</style>
</head>
<body>
<!-- 网页导航部分 -->
<table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
 <tr>
	<td colspan="2" height="20px" align="right" bgcolor="aeaeae" style="padding-right:100px">	
	<?php if(!(empty(\think\Request::instance()->session('username')) || ((\think\Request::instance()->session('username') instanceof \think\Collection || \think\Request::instance()->session('username') instanceof \think\Paginator ) && \think\Request::instance()->session('username')->isEmpty()))): ?>
	欢迎您：<?php echo \think\Request::instance()->session('username'); ?> 
	<a href="<?php echo Url('user/index/logout'); ?>">退出</a>
	<?php endif; if(empty(\think\Request::instance()->session('username')) || ((\think\Request::instance()->session('username') instanceof \think\Collection || \think\Request::instance()->session('username') instanceof \think\Paginator ) && \think\Request::instance()->session('username')->isEmpty())): ?>
    <a href="<?php echo Url('user/index/login'); ?>">登录</a>
    <a href="<?php echo Url('user/index/register'); ?>">注册</a>
	<?php endif; ?>	
	 </td>
 </tr>	 
 <tr>
	<td colspan="2" height="20px" align="center" bgcolor="#eeeefe">
	<a href="<?php echo Url('user/index/index'); ?>">首页</a> &nbsp; &nbsp; &nbsp; &nbsp;
	<a href="<?php echo Url('user/index/search'); ?>">搜索</a> &nbsp; &nbsp; &nbsp; &nbsp;
	<a href="<?php echo Url('user/orders/shoppingcar'); ?>">我的购物车</a> &nbsp; &nbsp; &nbsp; &nbsp;
	<a href="<?php echo Url('user/orders/myorders'); ?>">我的订单</a> &nbsp; &nbsp; &nbsp; &nbsp;
	 </td>
 </tr>
</table> 

<table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF"> 
<tr><!-- 网页左边显示类别 -->
	<td width="20%" height="500px" valign="top" align="center" bgcolor="#e0e0e0">
	<p>所有类别</p>
	<?php if(is_array($clist) || $clist instanceof \think\Collection || $clist instanceof \think\Paginator): $i = 0; $__LIST__ = $clist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$c): $mod = ($i % 2 );++$i;?>
	 <p><a href="<?php echo Url('user/index/product_list',['cid' => $c['cId']]); ?>"><?php echo $c['cName']; ?></a></p>
	<?php endforeach; endif; else: echo "" ;endif; ?>
	</td>
	<td bgcolor="#0e0e00e"><!-- 网页主体内容部分 -->
	
<p/>商品详情<p/>
<hr/>
<table border="1px" align="center">
 <tr>
   <td colspan="2"><h2><?php echo $product['pName']; ?></h2></td>
 </tr> 
 <tr bgcolor="#FFFFFF">
 <td><img src="__STATIC__/upload/<?php echo $product['pImg']; ?>" width="200px" height="200px"></td>
 <td> 
 描述：<?php echo $product['pDescr']; ?>
 <p/>
 价格：<?php echo $product['pPrice']; ?>元
  <p/> 
 <input type="button" id="addToCar" name="addToCar" value="加入购物车" onclick="window.location.href='../../addToCar/id/<?php echo $product['pId']; ?>'" />
  </td>
 </tr>
 <tr>
   <td colspan="2">
   <h3>商品详情</h3>
   <p/>
   <?php echo $product['pDescrDetail']; ?>    
   </td> 
   </tr>  
 <tr>
   <td colspan="2">
   <a href=# onclick="history.go(-1);">返回</a>
   </td>   
   </tr>
</table>

	</td>
</tr>
</table>
</body>
</html>
