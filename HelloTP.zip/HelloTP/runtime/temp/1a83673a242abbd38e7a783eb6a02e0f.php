<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:73:"D:\xampp\htdocs\HelloTP\public/../application/admin\view\index\index.html";i:1720940470;s:58:"D:\xampp\htdocs\HelloTP\application\admin\view\layout.html";i:1721289393;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>管理员后台</title>
<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #ccc; /* 修改这里的颜色值 */
}

header {
    background-color: #FFFFFF;
    height: 40px;
    padding-right: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ccc;
}

header div {
    margin-left: auto;
}


.sidebar {
    background-color: #3d3b3b;
    width: 200px;
    height: 100vh; /* 修改为100vh以覆盖整个视口高度 */
    padding: 10px;
    box-sizing: border-box;
    position: fixed; /* 固定侧边栏 */
    top: 0; /* 顶部对齐 */
    left: 0; /* 左侧对齐 */
    transition: margin-left 0.3s ease; /* 添加过渡效果 */
}

.sidebar.collapsed {
    margin-left: -200px; /* 收缩后的宽度 */
}

.content {
    padding: 20px;
    margin-left: 220px; /* 200px 侧边栏宽度 + 20px 边距 */
    transition: margin-left 0.3s ease; /* 添加过渡效果 */
}

.content.collapsed {
    margin-left: 20px; /* 收缩后的边距 */
}



/* 添加按钮样式 */
.toggle-btn {
    position: fixed;
    top: 45px;
    left: 200px;
    background-color: #333;
    color: #fff;
    padding: 5px 10px;
    cursor: pointer;
    transition: left 0.3s ease; /* 添加过渡效果 */
}

.sidebar.collapsed + .toggle-btn {
    left: 0;
}

/* 下拉菜单样式 */
.dropdown {
    margin-bottom: 10px;
}

.dropdown p {
    margin: 0;
    padding: 10px;
    background-color: #3d3b3b;
    cursor: pointer;
    color: #fbf3f3;
}

.dropdown-content {
    display: none;
    padding-left: 20px;
}

.dropdown-content a {
    display: block;
    padding: 5px 0;
    text-decoration: none;
    color: #fbf3f3;
}
</style>
</head>
<body>

<header>
    <div>
        <?php if(!(empty(\think\Request::instance()->session('adminName')) || ((\think\Request::instance()->session('adminName') instanceof \think\Collection || \think\Request::instance()->session('adminName') instanceof \think\Paginator ) && \think\Request::instance()->session('adminName')->isEmpty()))): ?>
            欢迎您：<?php echo \think\Request::instance()->session('adminName'); ?> 
            <a href="<?php echo Url('admin/index/logout'); ?>">退出</a>
        <?php endif; if(empty(\think\Request::instance()->session('adminName')) || ((\think\Request::instance()->session('adminName') instanceof \think\Collection || \think\Request::instance()->session('adminName') instanceof \think\Paginator ) && \think\Request::instance()->session('adminName')->isEmpty())): ?>
            <script>alert('你还没登录，请先登录!');window.location.href= "<?php echo Url('admin/index/login'); ?>";</script>
        <?php endif; ?>
    </div>
</header>


<div class="sidebar" id="sidebar">
    <div class="dropdown">
        <p><a href="<?php echo Url('admin/index/index'); ?>" style="color: #fbf3f3; text-decoration: none;">系统首页</a></p>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">管理员信息管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/index/adminNew'); ?>">增加管理员</a>
            <a href="<?php echo Url('admin/index/adminMaint'); ?>">维护管理员</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">商品信息管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/product/productNew'); ?>">增加商品</a>
            <a href="<?php echo Url('admin/product/index'); ?>">维护商品</a>
            <a href="<?php echo Url('admin/product/listup'); ?>">已上架商品</a>
            <a href="<?php echo Url('admin/product/listdown'); ?>">未上架商品</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">上传管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/index/uploadPic'); ?>">上传商品图片</a>
            <a href="<?php echo Url('admin/index/deletePic'); ?>">删除商品图片</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">订单管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/orders/index'); ?>">所有订单</a>
            <a href="<?php echo Url('admin/orders/orders0'); ?>">待付款订单</a>
            <a href="<?php echo Url('admin/orders/orders1'); ?>">待发货订单</a>
            <a href="<?php echo Url('admin/orders/orders2'); ?>">待收货订单</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">用户评价</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/ordercomments/index'); ?>">订单评价</a>
            <a href="<?php echo Url('admin/ordercomments/productComment'); ?>">商品评价</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">功能</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/reply/index'); ?>">功能处，记得修改链接</a>
            <a href="<?php echo Url('admin/reply/create'); ?>">功能处，记得修改链接</a>
        </div>
    </div>
</div>

<!-- 添加按钮 -->
<div class="toggle-btn" onclick="toggleSidebar()">≡</div>

<div class="content" id="content">
    
<style>
    /* 卡片样式 */
    .card {
        background-color: #f9f9f9;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
        padding: 20px;
        transition: transform 0.2s;
    }

    .card:hover {
        transform: translateY(-5px);
    }

    .card h3 {
        margin: 0;
        margin-bottom: 15px;
        color: #333;
    }

    .card p {
        margin: 0;
        color: #777;
    }

    .card .stats {
        display: flex;
        justify-content: space-around;
        margin-top: 20px;
    }

    .card .stats div {
        text-align: center;
        flex: 1;
    }

    .card .stats div:not(:last-child) {
        border-right: 1px solid #ddd;
    }

    .card .stats h4 {
        margin: 0;
        color: #555;
    }

    .card .stats p {
        margin: 5px 0 0;
        color: #111;
        font-size: 18px;
        font-weight: bold;
    }

    /* 最近活动样式 */
    .activity-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .activity-list li {
        padding: 15px;
        border-bottom: 1px solid #eee;
        display: flex;
        align-items: center;
    }

    .activity-list li:last-child {
        border-bottom: none;
    }

    .activity-list li .icon {
        background-color: #4caf50;
        color: #fff;
        border-radius: 50%;
        padding: 10px;
        margin-right: 10px;
    }

    .activity-list li .details {
        flex: 1;
    }

    .activity-list li .time {
        color: #bbb;
        font-size: 12px;
    }

    .quick-actions {
        display: flex;
        justify-content: space-around;
        margin-top: 20px;
    }

    .quick-actions a {
        display: block;
        padding: 10px 20px;
        background-color: #007bff;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s;
    }

    .quick-actions a:hover {
        background-color: #0056b3;
    }

    /* 用户评价样式 */
    .reviews-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .reviews-list li {
        padding: 15px;
        border-bottom: 1px solid #eee;
        display: flex;
        align-items: center;
    }

    .reviews-list li:last-child {
        border-bottom: none;
    }

    .reviews-list li .avatar {
        background-color: #007bff;
        color: #fff;
        border-radius: 50%;
        padding: 10px;
        margin-right: 10px;
        font-size: 24px;
        font-weight: bold;
        text-align: center;
        width: 50px;
        height: 50px;
        line-height: 30px;
    }

    .reviews-list li .details {
        flex: 1;
    }

    .reviews-list li .rating {
        color: #ff9800;
        font-size: 14px;
    }

    .reviews-list li .time {
        color: #bbb;
        font-size: 12px;
    }
</style>
<div class="card">
    <h3>欢迎您，管理员 <?php echo \think\Request::instance()->session('adminName'); ?></h3>
    <p>这是您的后台首页，您可以在这里管理商城的各项事务。</p>
</div>

<div class="card">
    <h3>统计信息</h3>
    <div class="stats">
        <div>
            <h4>用户数</h4>
            <p>1234</p>
        </div>
        <div>
            <h4>订单数</h4>
            <p>567</p>
        </div>
        <div>
            <h4>销售额</h4>
            <p>￥89,000</p>
        </div>
    </div>
</div>

<div class="card">
    <h3>快捷操作</h3>
    <div class="quick-actions">
        <a href="<?php echo Url('admin/product/productNew'); ?>">添加新商品</a>
        <a href="<?php echo Url('admin/orders/index'); ?>">查看订单</a>
        <a href="<?php echo Url('admin/index/uploadPic'); ?>">上传图片</a>
    </div>
</div>

<div class="card">
    <h3>最近活动</h3>
    <ul class="activity-list">
        <li>
            <div class="icon">A</div>
            <div class="details">
                管理员A添加了新商品“商品1”
                <div class="time">10分钟前</div>
            </div>
        </li>
        <li>
            <div class="icon">B</div>
            <div class="details">
                管理员B更新了订单“订单123”状态
                <div class="time">30分钟前</div>
            </div>
        </li>
        <li>
            <div class="icon">C</div>
            <div class="details">
                管理员C上传了新的商品图片
                <div class="time">1小时前</div>
            </div>
        </li>
    </ul>
</div>

<div class="card">
    <h3>用户评价</h3>
    <ul class="reviews-list">
        <li>
            <div class="avatar">张</div>
            <div class="details">
                <p><strong>张三</strong> 购买了“商品1”</p>
                <p class="rating">★★★★☆</p>
                <p>商品质量很好，物流也很快，下次还会再来！</p>
                <div class="time">2小时前</div>
            </div>
        </li>
        <li>
            <div class="avatar">李</div>
            <div class="details">
                <p><strong>李四</strong> 购买了“商品2”</p>
                <p class="rating">★★★★★</p>
                <p>客服服务态度很好，解答非常耐心。</p>
                <div class="time">1天前</div>
            </div>
        </li>
        <li>
            <div class="avatar">王</div>
            <div class="details">
                <p><strong>王五</strong> 购买了“商品3”</p>
                <p class="rating">★★★☆☆</p>
                <p>商品一般，价格有点高。</p>
                <div class="time">3天前</div>
            </div>
        </li>
    </ul>
</div>

</div>



<script>
function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    var content = document.getElementById('content');
    var toggleBtn = document.querySelector('.toggle-btn');
    sidebar.classList.toggle('collapsed');
    content.classList.toggle('collapsed');
    toggleBtn.classList.toggle('collapsed');
}

function toggleDropdown(element) {
    var content = element.nextElementSibling;
    if (content.style.display === "block") {
        content.style.display = "none";
    } else {
        content.style.display = "block";
    }
}
</script>

</body>
</html>