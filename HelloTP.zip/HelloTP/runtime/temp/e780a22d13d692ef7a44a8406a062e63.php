<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\xampp\htdocs\HelloTP\public/../application/admin\view\index\update.html";i:1720600071;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>修改商品</title>
</head>
<body>
    <h1>一个简单的修改商品页面</h1>
    <form action="<?php echo Url('admin/index/updatecheck'); ?>" method="post">
	商品ID<input type="text" name="pId" readonly value="<?php echo $product['pId']; ?>"></input><br/>
    商品名<input type="text" name="pName" value="<?php echo $product['pName']; ?>"></input><br/>
    商品价格<input type="text" name="pPrice" value="<?php echo $product['pPrice']; ?>"></input><br/>
	商品简介<input type="text" name="pDescr" value="<?php echo $product['pDescr']; ?>"></input><br/>
	商品图片
    <select name='pImg' id='pImg' required="true">
		<option value="">请选择图片</option>
		<?php if(is_array($files) || $files instanceof \think\Collection || $files instanceof \think\Paginator): if( count($files)==0 ) : echo "" ;else: foreach($files as $key=>$data): if(($data!='.') and ($data!='..')): if(($data==$product['pImg'])): ?>
			  <option value='<?php echo $data; ?>' selected='selected'><?php echo $data; ?></option>
			<?php else: ?>
			  <option value='<?php echo $data; ?>'><?php echo $data; ?></option>
			<?php endif; endif; endforeach; endif; else: echo "" ;endif; ?>	
	</select>	<br/>
    <input type="submit">
    </form>
</body>
</html>

