<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:79:"D:\xampp\htdocs\HelloTP\public/../application/user\view\orders\shoppingcar.html";i:1720676556;s:58:"D:\xampp\htdocs\HelloTP\application\user\view\layout2.html";i:1720668520;}*/ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>B2C网站会员后台</title>
<style>
ul{overflow:hidden;width:100%;}
ul li{list-style:none;width:33.333%;float:left;}
</style>
</head>
<body>
<!-- 网页导航部分 -->
<table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
 <tr>
	<td colspan="2" height="20px" align="right" bgcolor="aeaeae" style="padding-right:100px">	
	<?php if(!(empty(\think\Request::instance()->session('username')) || ((\think\Request::instance()->session('username') instanceof \think\Collection || \think\Request::instance()->session('username') instanceof \think\Paginator ) && \think\Request::instance()->session('username')->isEmpty()))): ?>
	欢迎您：<?php echo \think\Request::instance()->session('username'); ?> 
	<a href="<?php echo Url('user/index/logout'); ?>">退出</a>
	<?php endif; if(empty(\think\Request::instance()->session('username')) || ((\think\Request::instance()->session('username') instanceof \think\Collection || \think\Request::instance()->session('username') instanceof \think\Paginator ) && \think\Request::instance()->session('username')->isEmpty())): ?>
		<script>alert('你还没登录，请先登录!');window.location.href= "<?php echo Url('user/index/login'); ?>";</script>
	<?php endif; ?>
	 </td>
 </tr>	 
 <tr>
	<td colspan="2" height="20px" align="center" bgcolor="#eeeefe">
	<a href="<?php echo Url('user/index/index'); ?>">网站首页</a> &nbsp; &nbsp; &nbsp; &nbsp;
	<a href="<?php echo Url('user/index/user'); ?>">我的首页</a> &nbsp; &nbsp; &nbsp; &nbsp;
	<a href="<?php echo Url('user/orders/shoppingcar'); ?>">我的购物车</a> &nbsp; &nbsp; &nbsp; &nbsp;
	<a href="<?php echo Url('user/orders/myorders'); ?>">我的订单</a> &nbsp; &nbsp; &nbsp; &nbsp;
	 </td>
 </tr>
</table> 

<table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF"> 
<tr><!-- 网页左边显示类别 -->
	<td width="20%" height="500px" valign="top" align="center" bgcolor="#e0e0e0">
		<p></p>
		<p><a href="<?php echo Url('user/orders/shoppingcar'); ?>">我的购物车</a></p>
		<p><a href="<?php echo Url('user/orders/myorders'); ?>">我的订单</a></p>
		<p><a href='#'>其它菜单自行添加</a></p>
	</td>
	<td bgcolor="#0e0e00e"><!-- 网页主体内容部分 -->
	
<?php if(empty($items) || (($items instanceof \think\Collection || $items instanceof \think\Paginator ) && $items->isEmpty())): ?>
购物车空空如也！
<?php endif; if(!(empty($items) || (($items instanceof \think\Collection || $items instanceof \think\Paginator ) && $items->isEmpty()))): ?>
<table>
<tr><td>图片</td><td>商品号</td><td>商品名</td><td>价格</td><td>数量</td><td>小计</td><td>操作</td></tr>
<?php if(is_array($items) || $items instanceof \think\Collection || $items instanceof \think\Paginator): if( count($items)==0 ) : echo "" ;else: foreach($items as $key=>$item): ?>
	<tr>
	<td><img width="100px" height="100px" src="__STATIC__/upload/<?php echo $item['pImg']; ?>" />
	</td><td class="pId" ><?php echo $item['pId']; ?></td>
	<td><?php echo substr($item['pName'],0,20); ?></td>
	<td><?php echo $item['pPrice']; ?></td>
	<td><input type="number" id="number<?php echo $item['pId']; ?>" name="number" required="true" min="1" value="<?php echo $item['number']; ?>"></td>
	<td><?php echo $item['totalPrice']; ?></td>
	<td><a href="deleteItem/id/<?php echo $item['pId']; ?>" onclick="return confirm('确定删除吗?');">删除</a></td>
	</tr>
<?php endforeach; endif; else: echo "" ;endif; ?>	
	<tr>	<td colspan="7" id="sumPrice">总价：<?php echo $sumPrice; ?> 元</td>
	</tr>	<tr>
	<td colspan="7">
	<input type="button" id="createOrder" name="createOrder" value="生成订单" onclick="window.location.href='createOrder'" />
    </td>	</tr>

	</table>
	</td>
</tr>
</table>
<?php endif; ?>
<script>
	window.onload=function(){
		inputs=document.getElementsByName("number");
		for(j = 0; j < inputs.length; j++) {
   			inputs[j].addEventListener("blur",function(){
   				//1/得到xhr对象
				var xhr=getXHR();
				//2.注册状态变化监听器
				xhr.onreadystatechange=function(){
		if(xhr.readyState==4)		 {
		if(xhr.status==200)
		 {	//alert("服务器响应了");//alert(xhr.responseText);
								if(xhr.responseText=="ok")	 {
	window.location.href="shoppingcar";
	} else{
		alert(xhr.responseText);
	}}}}
	//3.建立与服务器的连接
	//xhr.open("POST","updateCar"+"?time="+new Date().getTime());
	xhr.open("POST","updateCar"+"?id="+this.id+"&num="+this.value);
	//4.向服务器发出请求
	xhr.send();
	},false);
	} 				
	};
	/** * 以下定义一个函数以获得 XMLHttpRequest对象 */
    function getXHR(){
	var xmlHttp;
	try {
		xmlHttp=new XMLHttpRequest();
	}catch(e)
	{
		try{
			xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
		}
		catch(e)
		{
			try{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch(e)
			{
				alert("你的浏览器不支持ajax");
				return false;
			}			
		}		
	}
	return xmlHttp;
}
</script>

	</td>
</tr>
</table>
</body>
</html>
