<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\xampp\htdocs\HelloTP\public/../application/user\view\index\index.html";i:1721180771;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | E-Shopper</title>
    <link href="__STATIC__/css/bootstrap.min.css" rel="stylesheet">
    <link href="__STATIC__/css/font-awesome.min.css" rel="stylesheet">
    <link href="__STATIC__/css/prettyPhoto.css" rel="stylesheet">
    <link href="__STATIC__/css/price-range.css" rel="stylesheet">
    <link href="__STATIC__/css/animate.css" rel="stylesheet">
	<link href="__STATIC__/css/main.css" rel="stylesheet">
	<link href="__STATIC__/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="__STATIC__/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="__STATIC__/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="__STATIC__/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="__STATIC__/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="__STATIC__/images/ico/apple-touch-icon-57-precomposed.png">
	<style>
		.sort-buttons {
			margin-bottom: 20px;
		}

		.sort-button {
			margin: 5px;
			padding: 10px 20px;
			border: 1px solid #ddd;
			background-color: #f8f8f8;
			color: #333;
			cursor: pointer;
			transition: background-color 0.3s, color 0.3s;
		}

		.sort-button:hover {
			background-color: #333;
			color: #fff;
		}
				
	</style>


</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> 131415310</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> info@hsxwg.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-md-4 clearfix">
						<div class="logo pull-left">
							<a href="<?php echo Url('user/index/index'); ?>"><img src="__STATIC__/images/home/logo.png" alt="" /></a>
						</div>
						<!-- <div class="btn-group pull-right clearfix">
							<div class="btn-group">
								<button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
									USA
									<span class="caret"></span>
								</button>
								<ul class="dropdown-menu">
									<li><a href="">Canada</a></li>
									<li><a href="">UK</a></li>
								</ul>
							</div>
							
							<div class="btn-group">
								<button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
									DOLLAR
									<span class="caret"></span>
								</button>
								<ul class="dropdown-menu">
									<li><a href="">Canadian Dollar</a></li>
									<li><a href="">Pound</a></li>
								</ul>
							</div>
						</div> -->
					</div>
					<div class="col-md-8 clearfix">
						<div class="shop-menu clearfix pull-right">
							<ul class="nav navbar-nav">
								<?php if(!(empty(\think\Request::instance()->session('username')) || ((\think\Request::instance()->session('username') instanceof \think\Collection || \think\Request::instance()->session('username') instanceof \think\Paginator ) && \think\Request::instance()->session('username')->isEmpty()))): ?>
								<li>
									<a href="">欢迎您：<?php echo \think\Request::instance()->session('username'); ?></a>
								</li>
								<li>
									<a href="<?php echo Url('user/index/logout'); ?>">退出</a>
								</li> 
								<?php endif; if(empty(\think\Request::instance()->session('username')) || ((\think\Request::instance()->session('username') instanceof \think\Collection || \think\Request::instance()->session('username') instanceof \think\Paginator ) && \think\Request::instance()->session('username')->isEmpty())): ?>
								<li>
									<a href="<?php echo Url('user/index/login'); ?>"><i class="fa fa-lock"></i> 登录|注册</a>
								<?php endif; ?>
								</li>
								<li><a href="<?php echo Url('user/orders/cart'); ?>"><i class="fa fa-shopping-cart"></i> 我的购物车</a></li>
								<li><a href="<?php echo Url('user/orders/myorders'); ?>"><i class="fa fa-crosshairs"></i> 我的订单</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					
					<div class="col-sm-3" style="width: 750px;margin-left:250px;">
						<div class="search_box pull-right" style="width: 750px;">
							<form method="get" action="<?php echo url('index/index'); ?>">
								<input type="text" name="search" placeholder="Search" value="<?php echo (isset($search) && ($search !== '')?$search:''); ?>" style="background-image:none;width: 700px;background: #F0F0E9;"/>
								<button type="submit" style="width: 45px;height:35px;display: inline-block;background: #FE980F;border:none;border-radius: 4px;">搜索</button>
							</form>
							<div class="popular_keywords" style="margin-top: 10px;">
								<h5>热门搜索：</h5>
								<ul style="list-style: none; padding: 0;">
									<?php if(is_array($popularKeywords) || $popularKeywords instanceof \think\Collection || $popularKeywords instanceof \think\Paginator): $i = 0; $__LIST__ = $popularKeywords;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$keyword): $mod = ($i % 2 );++$i;?>
										<li style="display: inline-block; margin-right: 10px;">
											<a href="?search=<?php echo $keyword['keyword']; ?>&sortOrder=<?php echo $sortOrder; ?>&sortType=<?php echo $sortType; ?>&minPrice=<?php echo $minPrice; ?>&maxPrice=<?php echo $maxPrice; ?>&category_id=<?php echo $currentCategoryId; ?>" style="font-size: {= 20 - ($key * 2)}px;"><?php echo $keyword['keyword']; ?></a>
										</li>
									<?php endforeach; endif; else: echo "" ;endif; ?>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	
	<section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<?php if(is_array($carouselImages) || $carouselImages instanceof \think\Collection || $carouselImages instanceof \think\Paginator): $key = 0; $__LIST__ = $carouselImages;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$image): $mod = ($key % 2 );++$key;?>
								<li data-target="#slider-carousel" data-slide-to="<?php echo $key; ?>" class="<?php if($key == 0): ?>active<?php endif; ?>"></li>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</ol>
	
						<div class="carousel-inner" style="height: 362.6px;">
							<?php if(is_array($carouselImages) || $carouselImages instanceof \think\Collection || $carouselImages instanceof \think\Paginator): $key = 0; $__LIST__ = $carouselImages;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$image): $mod = ($key % 2 );++$key;?>
								<div class="item <?php if($key == 3): ?>active<?php endif; ?>">
									<div class="col-sm-6">
										<h1><span>E</span>-SHOPPER</h1>
										<h2>Free E-Commerce Template</h2>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
										<!-- <a href="<?php echo url('index/product_details', ['id' => $image['productId']]); ?>" class="btn btn-default get">Get it now</a> -->
									</div>
									<div class="col-sm-6">
										<img src="<?php echo $image['url']; ?>" class="girl img-responsive" alt="" />
										<img src="__STATIC__/images/home/pricing.png" class="pricing" alt="" />
									</div>
								</div>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</div>
	
						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div>
				</div>
			</div>
		</div>
	</section><!--/slider-->
	
	

	
	
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian">
							<?php echo $categoryHtml; ?> <!-- 确保输出为HTML而不是转义后的字符串 -->
						</div>
						<div class="price-range">
							<h2>Price Range</h2>
							<div class="well text-center">
								<input type="text" class="span2" value="" data-slider-min="0" data-slider-max="10000" data-slider-step="5" data-slider-value="[0,10000]" id="priceRangeSlider"><br />
								<b class="pull-left">$ 0</b> <b class="pull-right">$ 10000</b>
								<button class="btn btn-primary" onclick="filterByPrice()">Filter</button>
								
							</div>
						</div>
						
						<div class="shipping text-center"><!--shipping-->
							<img src="__STATIC__/images/home/shipping.jpg" alt="" />
						</div><!--/shipping-->
					
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="features_items">
						<h2 class="title text-center">特色商品</h2>
						<div class="sort-buttons text-center">
							<button id="sortSalesButton" class="sort-button" onclick="toggleSortOrder('sales')">按销量排序</button>
							<button id="sortTimeButton" class="sort-button" onclick="toggleSortOrder('time')">按时间排序</button>
						</div>
						<?php if(is_array($products) || $products instanceof \think\Collection || $products instanceof \think\Paginator): $i = 0; $__LIST__ = $products;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<img width="242px" height="225px" src="__STATIC__/upload/<?php echo $data['pImg']; ?>" alt="" />
										<h2>￥： <?php echo $data['pPrice']; ?></h2>
										<p><?php echo $data['pName']; ?></p>
										<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>加入购物车</a>
									</div>
									<div class="product-overlay">
										<div class="overlay-content">
											<h2>￥： <?php echo $data['pPrice']; ?></h2>
											<p><?php echo $data['pName']; ?></p>
											<a href="<?php echo Url('user/index/product_details'); ?>?id=<?php echo $data['pId']; ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>商品详情</a>
										</div>
									</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>加入愿望清单</a></li>
										<li><a href="#"><i class="fa fa-plus-square"></i>加入对比</a></li>
									</ul>
								</div>
							</div>
						</div>
						<?php endforeach; endif; else: echo "" ;endif; ?>
						<div class="pagination-area">
							<ul class="pagination">
								<?php if($pageCount >= 1): ?>
								<li>
									<a href="?page=<?php echo $currentPage>1?$currentPage-1 : 1; ?>&search=<?php echo $search; ?>&sortOrder=<?php echo $sortOrder; ?>&sortType=<?php echo $sortType; ?>&minPrice=<?php echo $minPrice; ?>&maxPrice=<?php echo $maxPrice; ?>&category_id=<?php echo $currentCategoryId; ?>">&laquo;</a>
								</li>
								<?php if(is_array($pages) || $pages instanceof \think\Collection || $pages instanceof \think\Paginator): $i = 0; $__LIST__ = $pages;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$i): $mod = ($i % 2 );++$i;?>
								<li class="<?php if($i == $currentPage): ?>active<?php endif; ?>">
									<a href="?page=<?php echo $i; ?>&search=<?php echo $search; ?>&sortOrder=<?php echo $sortOrder; ?>&sortType=<?php echo $sortType; ?>&minPrice=<?php echo $minPrice; ?>&maxPrice=<?php echo $maxPrice; ?>&category_id=<?php echo $currentCategoryId; ?>"><?php echo $i; ?></a>
								</li>
								<?php endforeach; endif; else: echo "" ;endif; ?>
								<li>
									<a href="?page=<?php echo $currentPage<$pageCount?$currentPage+1 : $pageCount; ?>&search=<?php echo $search; ?>&sortOrder=<?php echo $sortOrder; ?>&sortType=<?php echo $sortType; ?>&minPrice=<?php echo $minPrice; ?>&maxPrice=<?php echo $maxPrice; ?>&category_id=<?php echo $currentCategoryId; ?>">&raquo;</a>
								</li>
								<?php endif; ?>
							</ul>
						</div>
						

					</div>
					

					
					
					
					
					<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">推荐商品</h2>
						
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<?php if(is_array($recommendedProducts) || $recommendedProducts instanceof \think\Collection || $recommendedProducts instanceof \think\Paginator): $i = 0; $__LIST__ = $recommendedProducts;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$product): $mod = ($i % 3 );++$i;if($i % 3 == 1): ?>
									<div class="item <?php if($i == 1): ?>active<?php endif; ?>"> 
									<?php endif; ?>
										<div class="col-sm-4">
											<div class="product-image-wrapper">
												<div class="single-products">
													<div class="productinfo text-center">
														<img width="200px" height="250px" src="__STATIC__/upload/<?php echo $product['pImg']; ?>" alt="" />
														<h2>￥<?php echo $product['pPrice']; ?></h2>
														<p><?php echo $product['pName']; ?></p>
														<a href="<?php echo Url('user/index/product_details'); ?>?id=<?php echo $product['pId']; ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>商品详情</a>
													</div>
												</div>
											</div>
										</div>
									<?php if($i % 3 == 0 || $i == count($recommendedProducts)): ?>
									</div>
									<?php endif; endforeach; endif; else: echo "" ;endif; ?>
							</div>
							<a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							</a>
							<a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							</a>            
						</div>
					</div><!--/recommended_items-->
					
					
				</div>
			</div>
		</div>
	</section>
	
	<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span>e</span>-shopper</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor</p>
						</div>
					</div>
					<div class="col-sm-7">
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="__STATIC__/images/home/iframe1.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="__STATIC__/images/home/iframe2.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="__STATIC__/images/home/iframe3.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="__STATIC__/images/home/iframe4.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="address">
							<img src="__STATIC__/images/home/map.png" alt="" />
							<p>505 S Atlantic Ave Virginia Beach, VA(Virginia)</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Service</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Online Help</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Order Status</a></li>
								<li><a href="#">Change Location</a></li>
								<li><a href="#">FAQ’s</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Quock Shop</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">T-Shirt</a></li>
								<li><a href="#">Mens</a></li>
								<li><a href="#">Womens</a></li>
								<li><a href="#">Gift Cards</a></li>
								<li><a href="#">Shoes</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Policies</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privecy Policy</a></li>
								<li><a href="#">Refund Policy</a></li>
								<li><a href="#">Billing System</a></li>
								<li><a href="#">Ticket System</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Company Information</a></li>
								<li><a href="#">Careers</a></li>
								<li><a href="#">Store Location</a></li>
								<li><a href="#">Affillate Program</a></li>
								<li><a href="#">Copyright</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<form action="#" class="searchform">
								<input type="text" placeholder="Your email address" />
								<button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
								<p>Get the most recent updates from <br />our site and be updated your self...</p>
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright &copy; 2024.Company name All rights reserved.</p>
					<p class="pull-right">Designed by <span><a target="_blank" href="#">TPboys</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	

  
    <script src="__STATIC__/js/jquery.js"></script>
	<script src="__STATIC__/js/bootstrap.min.js"></script>
	<script src="__STATIC__/js/jquery.scrollUp.min.js"></script>
	<script src="__STATIC__/js/price-range.js"></script>
    <script src="__STATIC__/js/jquery.prettyPhoto.js"></script>
    <script src="__STATIC__/js/main.js"></script>


	<script>
		
		function loadCategoryProducts(categoryId) {
			// 重定向到当前页面，附带所选分类的ID
			window.location.href = "?category_id=" + categoryId;
		}
		let sortOrder = 'desc'; // 初始排序方式为降序
		let sortType = 'sales'; // 初始排序类型为销量

		// 从URL中获取排序参数
		const urlParams = new URLSearchParams(window.location.search);
		sortOrder = urlParams.get('sortOrder') || sortOrder;
		sortType = urlParams.get('sortType') || sortType;

		// 更新按钮显示状态
		document.getElementById('sortSalesButton').textContent = (sortType === 'sales' && sortOrder === 'asc') ? '按销量升序' : '按销量降序';
		document.getElementById('sortTimeButton').textContent = (sortType === 'time' && sortOrder === 'asc') ? '按时间升序' : '按时间降序';

		function toggleSortOrder(type) {
			if (type === sortType) {
				sortOrder = (sortOrder === 'desc') ? 'asc' : 'desc'; // 切换排序方式
			} else {
				sortType = type;
				sortOrder = 'desc'; // 新排序类型时重置为降序
			}
			urlParams.set('sortOrder', sortOrder); // 添加或更新URL参数
			urlParams.set('sortType', sortType); // 添加或更新URL参数
			window.location.search = urlParams.toString(); // 重新加载页面
		}

		function filterByPrice() {
			const priceRange = $('#priceRangeSlider').val().split(','); // 获取价格范围
			const minPrice = priceRange[0] || 0; // 默认最小价格为0
			const maxPrice = priceRange[1] || 10000; // 默认最大价格为10000
			urlParams.set('minPrice', minPrice);
			urlParams.set('maxPrice', maxPrice);
			window.location.search = urlParams.toString(); // 重新加载页面
		}

		$(document).ready(function() {
			$('#priceRangeSlider').slider();
		});
		</script>
		
</body>
</html>