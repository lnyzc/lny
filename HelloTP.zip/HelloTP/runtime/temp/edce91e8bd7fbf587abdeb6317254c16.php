<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:80:"D:\xampp\htdocs\HelloTP\public/../application/admin\view\product\productnew.html";i:1721135158;s:58:"D:\xampp\htdocs\HelloTP\application\admin\view\layout.html";i:1721114212;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>管理员后台</title>
<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #ccc; /* 修改这里的颜色值 */
}

header {
    background-color: #FFFFFF;
    height: 40px;
    padding-right: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ccc;
}

header div {
    margin-left: auto;
}


.sidebar {
    background-color: #3d3b3b;
    width: 200px;
    height: 100vh; /* 修改为100vh以覆盖整个视口高度 */
    padding: 10px;
    box-sizing: border-box;
    position: fixed; /* 固定侧边栏 */
    top: 0; /* 顶部对齐 */
    left: 0; /* 左侧对齐 */
    transition: margin-left 0.3s ease; /* 添加过渡效果 */
}

.sidebar.collapsed {
    margin-left: -200px; /* 收缩后的宽度 */
}

.content {
    padding: 20px;
    margin-left: 220px; /* 200px 侧边栏宽度 + 20px 边距 */
    transition: margin-left 0.3s ease; /* 添加过渡效果 */
}

.content.collapsed {
    margin-left: 20px; /* 收缩后的边距 */
}



/* 添加按钮样式 */
.toggle-btn {
    position: fixed;
    top: 45px;
    left: 200px;
    background-color: #333;
    color: #fff;
    padding: 5px 10px;
    cursor: pointer;
    transition: left 0.3s ease; /* 添加过渡效果 */
}

.sidebar.collapsed + .toggle-btn {
    left: 0;
}

/* 下拉菜单样式 */
.dropdown {
    margin-bottom: 10px;
}

.dropdown p {
    margin: 0;
    padding: 10px;
    background-color: #3d3b3b;
    cursor: pointer;
    color: #fbf3f3;
}

.dropdown-content {
    display: none;
    padding-left: 20px;
}

.dropdown-content a {
    display: block;
    padding: 5px 0;
    text-decoration: none;
    color: #fbf3f3;
}
</style>
</head>
<body>

<header>
    <div>
        <?php if(!(empty(\think\Request::instance()->session('adminName')) || ((\think\Request::instance()->session('adminName') instanceof \think\Collection || \think\Request::instance()->session('adminName') instanceof \think\Paginator ) && \think\Request::instance()->session('adminName')->isEmpty()))): ?>
            欢迎您：<?php echo \think\Request::instance()->session('adminName'); ?> 
            <a href="<?php echo Url('admin/index/logout'); ?>">退出</a>
        <?php endif; if(empty(\think\Request::instance()->session('adminName')) || ((\think\Request::instance()->session('adminName') instanceof \think\Collection || \think\Request::instance()->session('adminName') instanceof \think\Paginator ) && \think\Request::instance()->session('adminName')->isEmpty())): ?>
            <script>alert('你还没登录，请先登录!');window.location.href= "<?php echo Url('admin/index/login'); ?>";</script>
        <?php endif; ?>
    </div>
</header>


<div class="sidebar" id="sidebar">
    <div class="dropdown">
        <p><a href="<?php echo Url('admin/index/index'); ?>" style="color: #fbf3f3; text-decoration: none;">系统首页</a></p>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">管理员信息管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/index/adminNew'); ?>">增加管理员</a>
            <a href="<?php echo Url('admin/index/adminMaint'); ?>">维护管理员</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">商品信息管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/product/productNew'); ?>">增加商品</a>
            <a href="<?php echo Url('admin/product/index'); ?>">维护商品</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">上传管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/index/uploadPic'); ?>">上传商品图片</a>
            <a href="<?php echo Url('admin/index/deletePic'); ?>">删除商品图片</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">订单管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/orders/index'); ?>">所有订单</a>
            <a href="<?php echo Url('admin/orders/orders0'); ?>">待付款订单</a>
            <a href="<?php echo Url('admin/orders/orders1'); ?>">待发货订单</a>
            <a href="<?php echo Url('admin/orders/orders2'); ?>">待收货订单</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">用户评价</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/ordercomments/index'); ?>">订单评价</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">功能</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/index/adminNew'); ?>">功能处，记得修改链接</a>
            <a href="<?php echo Url('admin/index/adminMaint'); ?>">功能处，记得修改链接</a>
        </div>
    </div>
</div>

<!-- 添加按钮 -->
<div class="toggle-btn" onclick="toggleSidebar()">≡</div>

<div class="content" id="content">
    
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 20px;
    }

    .container {
        max-width: 800px;
        margin: 0 auto;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        padding: 20px;
    }

    h2 {
        text-align: center;
        color: #333;
        margin-bottom: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    table, th, td {
        border: none;
    }

    th, td {
        padding: 12px;
        text-align: left;
    }

    th {
        background-color: #f9f9f9;
    }

    td img {
        border-radius: 5px;
    }

    input[type="text"], select, textarea {
        width: 100%;
        padding: 10px;
        margin: 5px 0 10px;
        border-radius: 5px;
        border: 1px solid #ddd;
        box-sizing: border-box;
    }

    input[type="submit"] {
        width: 100%;
        padding: 10px;
        border-radius: 5px;
        border: none;
        background-color: #007bff;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #0056b3;
    }

    .form-group {
        margin-bottom: 15px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    .required {
        color: red;
    }
</style>
<script type="text/javascript" charset="utf-8" src="__JS__/ueditor/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="__JS__/ueditor/ueditor.all.min.js"></script>
<script type="text/javascript" charset="utf-8" src="__JS__/ueditor/lang/zh-cn/zh-cn.js"></script>
<div class="container">
    <h2>增加商品</h2>
<form id='form1' name='form1' method='post' action='productNewCheck'>
    <div class="form-group">
        <label for="pClassId">商品类别 <span class="required">*</span></label>
        <select id="pClassId" name="pClassId" required>
            <option value="">请选择...</option>
            <?php if(is_array($classes) || $classes instanceof \think\Collection || $classes instanceof \think\Paginator): if( count($classes)==0 ) : echo "" ;else: foreach($classes as $key=>$class): ?>
                <option value='<?php echo $class["cId"]; ?>'><?php echo $class["cName"]; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="pName">商品名 <span class="required">*</span></label>
        <input name="pName" type="text" id="pName" required>
    </div>

    <div class="form-group">
        <label for="pPrice">商品价格 <span class="required">*</span></label>
        <input name="pPrice" type="text" id="pPrice" required pattern="\d+(\.\d{1,2})?" title="请输入有效的价格">
    </div>

    <div class="form-group">
        <label for="pImg">商品图片 <span class="required">*</span></label>
        <select name='pImg' id='pImg' required>
            <option value="">请选择图片</option>
            <?php if(is_array($files) || $files instanceof \think\Collection || $files instanceof \think\Paginator): if( count($files)==0 ) : echo "" ;else: foreach($files as $key=>$data): if(($data!='.') and ($data!='..')): ?>
                    <option value='<?php echo $data; ?>'><?php echo $data; ?></option>
                <?php endif; endforeach; endif; else: echo "" ;endif; ?>
        </select>
        <br/>
        <img id='img1' name='img1' width='100px' height='100px' src='#' alt="商品图片预览" />
    </div>

    <div class="form-group">
        <label for="pDescr">商品简介 <span class="required">*</span></label>
        <textarea name="pDescr" id="pDescr" rows="3" required></textarea>
    </div>

    <div class="form-group">
        <label for="pDescrDetail">商品详情</label>
        <script id="pDescrDetail" name="pDescrDetail" type="text/plain" style="width:100%;height:300px;"></script>
    </div>

    <div class="form-group">
        <label for="pStock">库存 <span class="required">*</span></label>
        <input name="pStock" type="number" id="pStock" required>
    </div>

    <div class="form-group">
        <label for="pUp">是否上架 <span class="required">*</span></label>
        <select id="pUp" name="pUp" required>
            <option value="0">否</option>
            <option value="1">是</option>
        </select>
    </div>

    <div class="form-group">
        <input type="submit" name="submit" value="增加商品" onclick="return confirm('确定要增加吗？');"/>
    </div>
</form>

</div>

<script type="text/javascript">
    //实例化编辑器
    var ue = UE.getEditor('pDescrDetail');

    window.onload = function() {
        document.getElementById("pImg").addEventListener("change", function() {
            var imgPath = "../../../static/upload/" + this.value;
            document.getElementById("img1").src = imgPath;
            document.getElementById("img1").style.display = 'block';
        });
    }
</script>
</div>



<script>
function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    var content = document.getElementById('content');
    var toggleBtn = document.querySelector('.toggle-btn');
    sidebar.classList.toggle('collapsed');
    content.classList.toggle('collapsed');
    toggleBtn.classList.toggle('collapsed');
}

function toggleDropdown(element) {
    var content = element.nextElementSibling;
    if (content.style.display === "block") {
        content.style.display = "none";
    } else {
        content.style.display = "block";
    }
}
</script>

</body>
</html>