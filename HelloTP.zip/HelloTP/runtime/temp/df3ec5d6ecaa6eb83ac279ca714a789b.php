<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:75:"D:\xampp\htdocs\HelloTP\public/../application/admin\view\product\index.html";i:1721186280;s:58:"D:\xampp\htdocs\HelloTP\application\admin\view\layout.html";i:1721269000;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>管理员后台</title>
<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #ccc; /* 修改这里的颜色值 */
}

header {
    background-color: #FFFFFF;
    height: 40px;
    padding-right: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ccc;
}

header div {
    margin-left: auto;
}


.sidebar {
    background-color: #3d3b3b;
    width: 200px;
    height: 100vh; /* 修改为100vh以覆盖整个视口高度 */
    padding: 10px;
    box-sizing: border-box;
    position: fixed; /* 固定侧边栏 */
    top: 0; /* 顶部对齐 */
    left: 0; /* 左侧对齐 */
    transition: margin-left 0.3s ease; /* 添加过渡效果 */
}

.sidebar.collapsed {
    margin-left: -200px; /* 收缩后的宽度 */
}

.content {
    padding: 20px;
    margin-left: 220px; /* 200px 侧边栏宽度 + 20px 边距 */
    transition: margin-left 0.3s ease; /* 添加过渡效果 */
}

.content.collapsed {
    margin-left: 20px; /* 收缩后的边距 */
}



/* 添加按钮样式 */
.toggle-btn {
    position: fixed;
    top: 45px;
    left: 200px;
    background-color: #333;
    color: #fff;
    padding: 5px 10px;
    cursor: pointer;
    transition: left 0.3s ease; /* 添加过渡效果 */
}

.sidebar.collapsed + .toggle-btn {
    left: 0;
}

/* 下拉菜单样式 */
.dropdown {
    margin-bottom: 10px;
}

.dropdown p {
    margin: 0;
    padding: 10px;
    background-color: #3d3b3b;
    cursor: pointer;
    color: #fbf3f3;
}

.dropdown-content {
    display: none;
    padding-left: 20px;
}

.dropdown-content a {
    display: block;
    padding: 5px 0;
    text-decoration: none;
    color: #fbf3f3;
}
</style>
</head>
<body>

<header>
    <div>
        <?php if(!(empty(\think\Request::instance()->session('adminName')) || ((\think\Request::instance()->session('adminName') instanceof \think\Collection || \think\Request::instance()->session('adminName') instanceof \think\Paginator ) && \think\Request::instance()->session('adminName')->isEmpty()))): ?>
            欢迎您：<?php echo \think\Request::instance()->session('adminName'); ?> 
            <a href="<?php echo Url('admin/index/logout'); ?>">退出</a>
        <?php endif; if(empty(\think\Request::instance()->session('adminName')) || ((\think\Request::instance()->session('adminName') instanceof \think\Collection || \think\Request::instance()->session('adminName') instanceof \think\Paginator ) && \think\Request::instance()->session('adminName')->isEmpty())): ?>
            <script>alert('你还没登录，请先登录!');window.location.href= "<?php echo Url('admin/index/login'); ?>";</script>
        <?php endif; ?>
    </div>
</header>


<div class="sidebar" id="sidebar">
    <div class="dropdown">
        <p><a href="<?php echo Url('admin/index/index'); ?>" style="color: #fbf3f3; text-decoration: none;">系统首页</a></p>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">管理员信息管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/index/adminNew'); ?>">增加管理员</a>
            <a href="<?php echo Url('admin/index/adminMaint'); ?>">维护管理员</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">商品信息管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/product/productNew'); ?>">增加商品</a>
            <a href="<?php echo Url('admin/product/index'); ?>">维护商品</a>
            <a href="<?php echo Url('admin/product/listup'); ?>">已上架商品</a>
            <a href="<?php echo Url('admin/product/listdown'); ?>">未上架商品</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">上传管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/index/uploadPic'); ?>">上传商品图片</a>
            <a href="<?php echo Url('admin/index/deletePic'); ?>">删除商品图片</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">订单管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/orders/index'); ?>">所有订单</a>
            <a href="<?php echo Url('admin/orders/orders0'); ?>">待付款订单</a>
            <a href="<?php echo Url('admin/orders/orders1'); ?>">待发货订单</a>
            <a href="<?php echo Url('admin/orders/orders2'); ?>">待收货订单</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">用户评价</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/ordercomments/index'); ?>">订单评价</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">功能</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/reply/index'); ?>">功能处，记得修改链接</a>
            <a href="<?php echo Url('admin/reply/create'); ?>">功能处，记得修改链接</a>
        </div>
    </div>
</div>

<!-- 添加按钮 -->
<div class="toggle-btn" onclick="toggleSidebar()">≡</div>

<div class="content" id="content">
    
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 20px;
    }

    .container {
        max-width: 1000px;
        margin: 0 auto;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        padding: 20px;
    }

    h2 {
        text-align: center;
        color: #333;
    }

    form {
        text-align: center;
        margin-bottom: 20px;
    }

    input[type="text"] {
        padding: 10px;
        width: 60%;
        border-radius: 5px;
        border: 1px solid #ddd;
    }

    input[type="submit"] {
        padding: 10px 20px;
        border-radius: 5px;
        border: none;
        background-color: #007bff;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #0056b3;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th, td {
        padding: 12px;
        text-align: center;
    }

    th {
        background-color: #f9f9f9;
    }

    td img {
        border-radius: 5px;
    }

    a {
        color: #007bff;
        text-decoration: none;
        transition: color 0.3s;
    }

    a:hover {
        color: #0056b3;
    }

    .pagination {
        text-align: center;
        margin-top: 20px;
    }

    .pagination li {
        list-style: none;
        display: inline-block;
        width: 30px;
    }

    .pagination a {
        color: #007bff;
        text-decoration: none;
        padding: 10px 15px;
        border-radius: 5px;
        border: 1px solid #ddd;
        margin: 0 5px;
        transition: background-color 0.3s, color 0.3s;
    }

    .pagination a:hover {
        background-color: #007bff;
        color: #fff;
    }

    .pagination .active a {
        background-color: #007bff;
        color: #fff;
        border: none;
    }
</style>
<div class="container">
    <h2>商品信息管理</h2>
    <form name="form1" method="get" action="">
        查询关键字 
        <input name="keyword" type="text" id="keyword" size="40" value="<?php echo $keyword; ?>">
        <input type="submit"  value="查询">
    </form>
    
    <table>
        <thead>
            <tr>
                <th>编号</th>
                <th>商品名</th>
                <th>图片</th>
                <th>价格</th>
                <th>简介</th>
                <th>类别号</th>
                <th>销量</th>
                <th>库存</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php if(is_array($products) || $products instanceof \think\Collection || $products instanceof \think\Paginator): if( count($products)==0 ) : echo "" ;else: foreach($products as $key=>$data): ?>
            <tr>
                <td><?php echo $data['pId']; ?></td>
                <td><?php echo substr($data['pName'],0,20); ?></td>
                <td><img width="100px" height="100px" src="../../../static/upload/<?php echo $data['pImg']; ?>" alt="商品图片"/></td>
                <td><?php echo $data['pPrice']; ?></td>
                <td><?php echo substr($data['pDescr'],0,20); ?></td>
                <td><?php echo $data['pClassId']; ?></td>
                <td><?php echo $data['pSales']; ?></td>
                <td>
                    <input type="number" value="<?php echo $data['pStock']; ?>" id="stock_<?php echo $data['pId']; ?>">
                </td>
                <td>
                    <?php if($data['pUp'] == 1): ?>
                        <a href="<?php echo Url('admin/product/down', ['id' => $data['pId']]); ?>">下架</a> |
                    <?php else: ?>
                        <a href="<?php echo Url('admin/product/up', ['id' => $data['pId']]); ?>">上架</a> |
                    <?php endif; ?>
                    <a href="<?php echo Url('admin/product/update', ['id' => $data['pId']]); ?>">修改</a> |
                    <a href="<?php echo Url('admin/product/delete', ['id' => $data['pId']]); ?>" onclick="return confirm('确定要删除吗？');">删除</a> |
                    <a href="<?php echo Url('admin/product/detail', ['id' => $data['pId']]); ?>">详情</a> |
                </td>
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </tbody>
    </table>
    <div class="pagination">
        <?php echo $products->render(); ?>
    </div>
</div>
<script>
    function updateStock(productId) {
        var stock = document.getElementById('stock_' + productId).value;
        
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "<?php echo Url('admin/product/updateStock'); ?>", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                alert('库存更新成功！');
                location.reload(); // 刷新页面以显示最新数据
            }
        };
        xhr.send("id=" + productId + "&stock=" + stock);
    }
    </script>
    
</div>



<script>
function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    var content = document.getElementById('content');
    var toggleBtn = document.querySelector('.toggle-btn');
    sidebar.classList.toggle('collapsed');
    content.classList.toggle('collapsed');
    toggleBtn.classList.toggle('collapsed');
}

function toggleDropdown(element) {
    var content = element.nextElementSibling;
    if (content.style.display === "block") {
        content.style.display = "none";
    } else {
        content.style.display = "block";
    }
}
</script>

</body>
</html>