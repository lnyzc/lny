<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\xampp\htdocs\HelloTP\public/../application/admin\view\index\addnew.html";i:1720599714;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>新增商品</title>
</head>
<body>
    <h1>一个简单的新增商品页面</h1>
    <form action="<?php echo Url('admin/index/addnewcheck'); ?>" method="post">
    商品名<input type="text" name="pName"></input><br/>
    商品价格<input type="text" name="pPrice"></input><br/>
	商品简介<input type="text" name="pDescr"></input><br/>
	商品图片
    <select name='pImg' id='pImg' required="true">
		<option value="">请选择图片</option>
		<?php if(is_array($files) || $files instanceof \think\Collection || $files instanceof \think\Paginator): if( count($files)==0 ) : echo "" ;else: foreach($files as $key=>$data): if(($data!='.') and ($data!='..')): ?>
		<option value='<?php echo $data; ?>'><?php echo $data; ?></option>
		<?php endif; endforeach; endif; else: echo "" ;endif; ?>	
	</select>	<br/>
    <input type="submit">
    </form>
</body>
</html>

