<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:76:"D:\xampp\htdocs\HelloTP\public/../application/admin\view\product\detail.html";i:1721129669;s:58:"D:\xampp\htdocs\HelloTP\application\admin\view\layout.html";i:1721114212;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>管理员后台</title>
<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #ccc; /* 修改这里的颜色值 */
}

header {
    background-color: #FFFFFF;
    height: 40px;
    padding-right: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ccc;
}

header div {
    margin-left: auto;
}


.sidebar {
    background-color: #3d3b3b;
    width: 200px;
    height: 100vh; /* 修改为100vh以覆盖整个视口高度 */
    padding: 10px;
    box-sizing: border-box;
    position: fixed; /* 固定侧边栏 */
    top: 0; /* 顶部对齐 */
    left: 0; /* 左侧对齐 */
    transition: margin-left 0.3s ease; /* 添加过渡效果 */
}

.sidebar.collapsed {
    margin-left: -200px; /* 收缩后的宽度 */
}

.content {
    padding: 20px;
    margin-left: 220px; /* 200px 侧边栏宽度 + 20px 边距 */
    transition: margin-left 0.3s ease; /* 添加过渡效果 */
}

.content.collapsed {
    margin-left: 20px; /* 收缩后的边距 */
}



/* 添加按钮样式 */
.toggle-btn {
    position: fixed;
    top: 45px;
    left: 200px;
    background-color: #333;
    color: #fff;
    padding: 5px 10px;
    cursor: pointer;
    transition: left 0.3s ease; /* 添加过渡效果 */
}

.sidebar.collapsed + .toggle-btn {
    left: 0;
}

/* 下拉菜单样式 */
.dropdown {
    margin-bottom: 10px;
}

.dropdown p {
    margin: 0;
    padding: 10px;
    background-color: #3d3b3b;
    cursor: pointer;
    color: #fbf3f3;
}

.dropdown-content {
    display: none;
    padding-left: 20px;
}

.dropdown-content a {
    display: block;
    padding: 5px 0;
    text-decoration: none;
    color: #fbf3f3;
}
</style>
</head>
<body>

<header>
    <div>
        <?php if(!(empty(\think\Request::instance()->session('adminName')) || ((\think\Request::instance()->session('adminName') instanceof \think\Collection || \think\Request::instance()->session('adminName') instanceof \think\Paginator ) && \think\Request::instance()->session('adminName')->isEmpty()))): ?>
            欢迎您：<?php echo \think\Request::instance()->session('adminName'); ?> 
            <a href="<?php echo Url('admin/index/logout'); ?>">退出</a>
        <?php endif; if(empty(\think\Request::instance()->session('adminName')) || ((\think\Request::instance()->session('adminName') instanceof \think\Collection || \think\Request::instance()->session('adminName') instanceof \think\Paginator ) && \think\Request::instance()->session('adminName')->isEmpty())): ?>
            <script>alert('你还没登录，请先登录!');window.location.href= "<?php echo Url('admin/index/login'); ?>";</script>
        <?php endif; ?>
    </div>
</header>


<div class="sidebar" id="sidebar">
    <div class="dropdown">
        <p><a href="<?php echo Url('admin/index/index'); ?>" style="color: #fbf3f3; text-decoration: none;">系统首页</a></p>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">管理员信息管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/index/adminNew'); ?>">增加管理员</a>
            <a href="<?php echo Url('admin/index/adminMaint'); ?>">维护管理员</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">商品信息管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/product/productNew'); ?>">增加商品</a>
            <a href="<?php echo Url('admin/product/index'); ?>">维护商品</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">上传管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/index/uploadPic'); ?>">上传商品图片</a>
            <a href="<?php echo Url('admin/index/deletePic'); ?>">删除商品图片</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">订单管理</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/orders/index'); ?>">所有订单</a>
            <a href="<?php echo Url('admin/orders/orders0'); ?>">待付款订单</a>
            <a href="<?php echo Url('admin/orders/orders1'); ?>">待发货订单</a>
            <a href="<?php echo Url('admin/orders/orders2'); ?>">待收货订单</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">用户评价</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/ordercomments/index'); ?>">订单评价</a>
        </div>
    </div>
    <div class="dropdown">
        <p onclick="toggleDropdown(this)">功能</p>
        <div class="dropdown-content">
            <a href="<?php echo Url('admin/index/adminNew'); ?>">功能处，记得修改链接</a>
            <a href="<?php echo Url('admin/index/adminMaint'); ?>">功能处，记得修改链接</a>
        </div>
    </div>
</div>

<!-- 添加按钮 -->
<div class="toggle-btn" onclick="toggleSidebar()">≡</div>

<div class="content" id="content">
    
<style>
.container {
     max-width: 800px;
     margin: 0 auto;
     background-color: #fff;
     border-radius: 10px;
     box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
     padding: 20px;
 }

 .container h2 {
     text-align: center;
     color: #333;
 }

 hr {
     border: none;
     border-top: 1px solid #ddd;
     margin: 20px 0;
 }

 table {
     width: 100%;
     border-collapse: collapse;
     margin: 20px 0;
 }

 table, th, td {
     border: 1px solid #ddd;
 }

 th, td {
     padding: 12px;
     text-align: left;
 }

 th {
     background-color: #f9f9f9;
 }

 td img {
     border-radius: 5px;
 }

 .back-link {
     text-align: center;
     margin-top: 20px;
 }

 .back-link a {
     color: #007bff;
     text-decoration: none;
     padding: 10px 20px;
     border: 1px solid #007bff;
     border-radius: 5px;
     transition: background-color 0.3s, color 0.3s;
 }

 .back-link a:hover {
     background-color: #007bff;
     color: #fff;
 }
</style>
<div class="container">
     <h2>商品详情</h2>
     <hr/>
     <table>
         <tr>
             <th>字段</th>
             <th>字段值</th>
         </tr>
         <tr>
             <td>编号</td>
             <td><?php echo $detail['pId']; ?></td>
         </tr>
         <tr>
             <td>商品名</td>
             <td><?php echo $detail['pName']; ?></td>
         </tr>
         <tr>
             <td>价格</td>
             <td><?php echo $detail['pPrice']; ?></td>
         </tr>
         <tr>
            <td>库存</td>
            <td><?php echo $detail['pStock']; ?></td>
        </tr>
        <tr>
            <td>销量</td>
            <td><?php echo $detail['pSales']; ?></td>
        </tr>
         <tr>
             <td>图片</td>
             <td><img src="__STATIC__/upload/<?php echo $detail['pImg']; ?>" width="100px" height="100px" alt="商品图片"></td>
         </tr>
         <tr>
             <td>简介</td>
             <td><?php echo $detail['pDescr']; ?></td>
         </tr>
         <tr>
             <td>类别号</td>
             <td><?php echo $detail['pClassId']; ?></td>
         </tr>
         <tr>
             <td>日期</td>
             <td><?php echo $detail['pTime']; ?></td>
         </tr>
         <tr>
             <td>详情</td>
             <td><?php echo $detail['pDescrDetail']; ?></td>
         </tr>
     </table>
     <div class="back-link">
         <a href="#" onclick="history.go(-1);">返回</a>
     </div>
 </div>

</div>



<script>
function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    var content = document.getElementById('content');
    var toggleBtn = document.querySelector('.toggle-btn');
    sidebar.classList.toggle('collapsed');
    content.classList.toggle('collapsed');
    toggleBtn.classList.toggle('collapsed');
}

function toggleDropdown(element) {
    var content = element.nextElementSibling;
    if (content.style.display === "block") {
        content.style.display = "none";
    } else {
        content.style.display = "block";
    }
}
</script>

</body>
</html>