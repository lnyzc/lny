<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"D:\xampp\htdocs\HelloTP\public/../application/user\view\index\product_details.html";i:1721283100;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Product Details | E-Shopper</title>
    <link href="__STATIC__/css/bootstrap.min.css" rel="stylesheet">
    <link href="__STATIC__/css/font-awesome.min.css" rel="stylesheet">
    <link href="__STATIC__/css/prettyPhoto.css" rel="stylesheet">
    <link href="__STATIC__/css/price-range.css" rel="stylesheet">
    <link href="__STATIC__/css/animate.css" rel="stylesheet">
	<link href="__STATIC__/css/main.css" rel="stylesheet">
	<link href="__STATIC__/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="__STATIC__/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="__STATIC__/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="__STATIC__/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="__STATIC__/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="__STATIC__/images/ico/apple-touch-icon-57-precomposed.png">
	<style>
		/* 用户评论样式 */
		.user-review {
			border: 1px solid #ddd;
			padding: 10px;
			margin-bottom: 10px;
			background-color: #f9f9f9;
		}

		/* 商家回复样式 */
		.admin-reply {
			border: 1px solid #007bff;
			padding: 10px;
			margin: 10px 0 10px 20px;
			/* background-color: #e6f7ff; */
		}

		.admin-reply ul {
			margin: 0;
			padding: 0;
			list-style-type: none;
		}

		.admin-reply ul li {
			display: inline;
			margin-right: 10px;
		}

		.admin-reply p {
			margin: 5px 0 0 0;
			font-size: 14px;
		}

	</style>
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href=""><i class="fa fa-phone"></i> 131415310</a></li>
								<li><a href=""><i class="fa fa-envelope"></i> info@domain.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href=""><i class="fa fa-facebook"></i></a></li>
								<li><a href=""><i class="fa fa-twitter"></i></a></li>
								<li><a href=""><i class="fa fa-linkedin"></i></a></li>
								<li><a href=""><i class="fa fa-dribbble"></i></a></li>
								<li><a href=""><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-md-4 clearfix">
						<div class="logo pull-left">
							<a href="index.html"><img src="__STATIC__/images/home/logo.png" alt="" /></a>
						</div>

					</div>
					<div class="col-md-8 clearfix">
						<div class="shop-menu clearfix pull-right">
							<ul class="nav navbar-nav">
								<?php if(!(empty(\think\Request::instance()->session('username')) || ((\think\Request::instance()->session('username') instanceof \think\Collection || \think\Request::instance()->session('username') instanceof \think\Paginator ) && \think\Request::instance()->session('username')->isEmpty()))): ?>
								<li>
									<a href="">欢迎您：<?php echo \think\Request::instance()->session('username'); ?></a>
								</li>
								<li>
									<a href="<?php echo Url('user/index/logout'); ?>">退出</a>
								</li> 
								<?php endif; if(empty(\think\Request::instance()->session('username')) || ((\think\Request::instance()->session('username') instanceof \think\Collection || \think\Request::instance()->session('username') instanceof \think\Paginator ) && \think\Request::instance()->session('username')->isEmpty())): ?>
								<li>
									<a href="<?php echo Url('user/index/login'); ?>"><i class="fa fa-lock"></i> 登录|注册</a>
								<?php endif; ?>
								</li>
								<li><a href="<?php echo Url('user/orders/cart'); ?>"><i class="fa fa-shopping-cart"></i> 我的购物车</a></li>
								<li><a href="<?php echo Url('user/orders/myorders'); ?>"><i class="fa fa-crosshairs"></i> 我的订单</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="<?php echo Url('user/index/index'); ?>">首页</a></li>
								<li class="dropdown"><a href="#">联系我们<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="#">phone:131415310</a></li>
										<li><a href="#" class="active">Email:usxwg@nb.com</a></li> 
										<!-- <li><a href="checkout.html">Checkout</a></li> 
										<li><a href="../orders/cart.html">Cart</a></li> 
										<li><a href="login.html">Login</a></li>  -->
                                    </ul>
                                </li> 
								<!-- <li class="dropdown"><a href="#">Blog<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="blog.html">Blog List</a></li>
										<li><a href="blog-single.html">Blog Single</a></li>
                                    </ul>
                                </li> 
								<li><a href="404.html">404</a></li>
								<li><a href="contact-us.html">联系我们</a></li> -->
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian">
							<?php echo $categoryHtml; ?> <!-- 确保输出为HTML而不是转义后的字符串 -->
						</div>
						<div class="shipping text-center"><!--shipping-->
							<img src="__STATIC__/images/home/shipping.jpg" alt="" />
						</div><!--/shipping-->
					
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
								<img src="__STATIC__/upload/<?php echo $product['pImg']; ?>" alt="" />
								<h3>ZOOM</h3>
							</div>

						</div>
						<div class="col-sm-7">
							<div class="product-information">
								<img src="__STATIC__/images/product-details/new.jpg" class="newarrival" alt="" />
								<h2><?php echo $product['pName']; ?></h2>
								<p>商品ID: <?php echo $product['pId']; ?></p>
								<span>
									<span id="productPrice"><?php echo $product['pPrice']; ?></span>
									<label>数量:</label>
									<input type="text" id="productQuantity" value="1" />
									<button id="addToCar" name="addToCar" type="button" class="btn btn-fefault cart" onclick="addToCart(<?php echo $product['pId']; ?>, $('#productQuantity').val())">
										<i class="fa fa-shopping-cart"></i>
										Add to cart
									</button>
									<button id="buyNow" name="buyNow" type="button" class="btn btn-fefault buy" onclick="buyNow(<?php echo $product['pId']; ?>, $('#productQuantity').val())">
										<i class="fa fa-credit-card"></i>
										Buy Now
									</button>
								</span>
								<p><b>简介:</b> <?php echo mb_substr($product['pDescr'], 0, 100); ?>...</p>
								<p><b>商品详情:</b> <?php echo mb_substr($product['pDescrDetail'], 0, 150); ?>...</p>
								<p><b>Brand:</b> E-SHOPPER</p>
								<a href=""><img src="__STATIC__/images/product-details/share.png" class="share img-responsive"  alt="" /></a>
							</div>
						</div>
						
						
					</div><!--/product-details-->
					
					<div class="category-tab shop-details-tab"><!--category-tab-->
						<div class="col-sm-12">
							<ul class="nav nav-tabs">
								<li class="active"><a href="#details" data-toggle="tab">商品详情</a></li>
								<li><a href="#reviews" data-toggle="tab">评论区(<?php echo $totalReviews; ?>)</a></li>
							</ul>
						</div>
						<div class="tab-content">
							<div class="tab-pane fade active in" id="details">
								<div class="col-sm-12">
									<p><?php echo $product['pDescrDetail']; ?></p>
								</div>
							</div>
							<div class="tab-pane fade" id="reviews">
								<div class="col-sm-12">
									<?php if(is_array($reviews) || $reviews instanceof \think\Collection || $reviews instanceof \think\Paginator): $i = 0; $__LIST__ = $reviews;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$review): $mod = ($i % 2 );++$i;?>
									<ul>
										<li><a href=""><i class="fa fa-user"></i><?php echo $review['uname']; ?></a></li>
										<li><a href=""><i class="fa fa-clock-o"></i><?php echo date('H:i A',strtotime($review['created_at'])); ?></a></li>
										<li><a href=""><i class="fa fa-calendar-o"></i><?php echo date('d M Y',strtotime($review['created_at'])); ?></a></li>
									</ul>
									<p><?php echo $review['message']; ?></p>
									<p><b>Rating: </b>
										<?php for($i = 1; $i <= $review['rating']; $i++): ?>
											<i class="fa fa-star"></i>
										<?php endfor; for($i = $review['rating'] + 1; $i <= 5; $i++): ?>
											<i class="fa fa-star-o"></i>
										<?php endfor; ?>
									</p>
									<!-- 商家回复 -->
									<?php if(!empty($review['reply_content'])): ?>
									<div class="admin-reply">
										<ul>
											<li><a href=""><i class="fa fa-user"></i>商家回复</a></li>
											<li><a href=""><i class="fa fa-clock-o"></i><?php echo date('H:i A',strtotime($review['reply_created_at'])); ?></a></li>
											<li><a href=""><i class="fa fa-calendar-o"></i><?php echo date('d M Y',strtotime($review['reply_created_at'])); ?></a></li>
										</ul>
										<p><?php echo $review['reply_content']; ?></p>
									</div>
									<?php endif; endforeach; endif; else: echo "" ;endif; ?>
					
									<div class="pagination-area">
										<?php echo $reviews->render(); ?>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					
					<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">推荐商品</h2>
						
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<?php if(is_array($recommendedProducts) || $recommendedProducts instanceof \think\Collection || $recommendedProducts instanceof \think\Paginator): $i = 0; $__LIST__ = $recommendedProducts;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$product): $mod = ($i % 3 );++$i;if($i % 3 == 1): ?>
									<div class="item <?php if($i == 1): ?>active<?php endif; ?>"> 
									<?php endif; ?>
										<div class="col-sm-4">
											<div class="product-image-wrapper">
												<div class="single-products">
													<div class="productinfo text-center">
														<img width="200px" height="250px" src="__STATIC__/upload/<?php echo $product['pImg']; ?>" alt="" />
														<h2>￥<?php echo $product['pPrice']; ?></h2>
														<p><?php echo $product['pName']; ?></p>
														<a href="<?php echo Url('user/index/product_details'); ?>?id=<?php echo $product['pId']; ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>商品详情</a>
													</div>
												</div>
											</div>
										</div>
									<?php if($i % 3 == 0 || $i == count($recommendedProducts)): ?>
									</div>
									<?php endif; endforeach; endif; else: echo "" ;endif; ?>
							</div>
							<a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							</a>
							<a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							</a>            
						</div>
					</div><!--/recommended_items-->
					
				</div>
			</div>
		</div>
	</section>
	
	<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span>e</span>-shopper</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor</p>
						</div>
					</div>
					<div class="col-sm-7">
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="__STATIC__/images/home/iframe1.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="__STATIC__/images/home/iframe2.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="__STATIC__/images/home/iframe3.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="video-gallery text-center">
								<a href="#">
									<div class="iframe-img">
										<img src="__STATIC__/images/home/iframe4.png" alt="" />
									</div>
									<div class="overlay-icon">
										<i class="fa fa-play-circle-o"></i>
									</div>
								</a>
								<p>Circle of Hands</p>
								<h2>24 DEC 2014</h2>
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="address">
							<img src="__STATIC__/images/home/map.png" alt="" />
							<p>505 S Atlantic Ave Virginia Beach, VA(Virginia)</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Service</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="">Online Help</a></li>
								<li><a href="">Contact Us</a></li>
								<li><a href="">Order Status</a></li>
								<li><a href="">Change Location</a></li>
								<li><a href="">FAQ’s</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Quock Shop</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="">T-Shirt</a></li>
								<li><a href="">Mens</a></li>
								<li><a href="">Womens</a></li>
								<li><a href="">Gift Cards</a></li>
								<li><a href="">Shoes</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Policies</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="">Terms of Use</a></li>
								<li><a href="">Privecy Policy</a></li>
								<li><a href="">Refund Policy</a></li>
								<li><a href="">Billing System</a></li>
								<li><a href="">Ticket System</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="">Company Information</a></li>
								<li><a href="">Careers</a></li>
								<li><a href="">Store Location</a></li>
								<li><a href="">Affillate Program</a></li>
								<li><a href="">Copyright</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<form action="#" class="searchform">
								<input type="text" placeholder="Your email address" />
								<button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
								<p>Get the most recent updates from <br />our site and be updated your self...</p>
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright &copy; 2022.Company name All rights reserved.<a target="_blank" href="https://sc.chinaz.com/moban/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></p>
					<p class="pull-right">Designed by <span><a target="_blank" href="#">Themeum</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	

  
    <script src="__STATIC__/js/jquery.js"></script>
	<script src="__STATIC__/js/price-range.js"></script>
    <script src="__STATIC__/js/jquery.scrollUp.min.js"></script>
	<script src="__STATIC__/js/bootstrap.min.js"></script>
    <script src="__STATIC__/js/jquery.prettyPhoto.js"></script>
    <script src="__STATIC__/js/main.js"></script>
	<script>
		function addToCart(id, quantity) {
			$.ajax({
				url: "<?php echo url('user/index/addToCar'); ?>",
				type: "POST",
				data: {id: id, num: quantity},
				success: function(response) {
					alert(response.message);
					if (response.status === 'ok') {
						location.reload();
					}
				},
				error: function() {
					alert("添加到购物车失败");
				}
			});
		}
		function buyNow(productId, quantity) {
			$.ajax({
				url: "<?php echo url('orders/createInstantOrder'); ?>",
				type: "POST",
				data: {
					productId: productId,
					quantity: quantity
				},
				success: function(response) {
					if (response.status === 'success') {
						window.location.href = "<?php echo url('orders/payment'); ?>?id=" + response.orderId;
					} else {
						alert(response.message);
					}
				},
				error: function() {
					alert("Error occurred while processing your request.");
				}
			});
		}



		function loadCategoryProducts(categoryId) {
			// 重定向到当前页面，附带所选分类的ID
			window.location.href = "index?category_id=" + categoryId;
		}
	</script>
</body>
</html>